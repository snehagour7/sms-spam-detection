import streamlit as st
import pandas as pd
import numpy as np
import string
from nltk.corpus import stopwords
import nltk
from nltk.stem.porter import PorterStemmer
import warnings
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
import pickle
import os

# Suppress warnings
warnings.filterwarnings('ignore')

# Download NLTK resources if not already downloaded
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

ps = PorterStemmer()

def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)

    y = []
    for i in text:
        if i.isalnum():
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        y.append(ps.stem(i))

    return " ".join(y)

# Load and prepare data
@st.cache_data
def load_data():
    df = pd.read_csv('spam.csv', encoding='latin-1')
    df = df.drop(['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4'], axis=1)
    df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)
    df['target'] = df['target'].map({'ham': 0, 'spam': 1})
    return df

# Train model
@st.cache_resource
def train_model(df):
    # Transform text
    df['transformed_text'] = df['text'].apply(transform_text)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        df['transformed_text'], df['target'], test_size=0.2, random_state=42
    )
    
    # Create and fit TF-IDF vectorizer
    tfidf = TfidfVectorizer()
    X_train_tfidf = tfidf.fit_transform(X_train)
    
    # Train model
    model = MultinomialNB()
    model.fit(X_train_tfidf, y_train)
    
    return tfidf, model

# Main app
st.title("Email/SMS Spam Classifier")

# Load data and train model
try:
    df = load_data()
    tfidf, model = train_model(df)
    st.success("Model trained successfully!")
except Exception as e:
    st.error(f"Error loading data or training model: {str(e)}")
    st.stop()

# Input area
input_sms = st.text_area("Enter the message")

if st.button('Predict'):
    if not input_sms:
        st.warning("Please enter a message to classify.")
    else:
        try:
            # 1. preprocess
            transformed_sms = transform_text(input_sms)
            # 2. vectorize
            vector_input = tfidf.transform([transformed_sms])
            # 3. predict
            result = model.predict(vector_input)[0]
            # 4. Display
            if result == 1:
                st.header("Spam")
            else:
                st.header("Not Spam")
        except Exception as e:
            st.error(f"Error during prediction: {str(e)}")
